/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

import connection.ConexionBD;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import model.Club;
import model.ClubDAO;
import model.HistorialClub;
import model.Jugador;
import model.JugadorDAO;

/**
 * Clase principal de la aplicación.
 *
 * @author Macarena
 */
public class App {

    //Scanner y objetos Jugador y Club.
    private static final Scanner escaner = new Scanner(System.in);
    private static final JugadorDAO jugadorDAO = new JugadorDAO();
    private static final ClubDAO clubDAO = new ClubDAO();

    /**
     * Método principal de la clase App.
     *
     * @param args
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException {
        int opcion;
        do {
            mostrarMenu();
            opcion = escaner.nextInt();
            escaner.nextLine();

            switch (opcion) {
                case 1:
                    insertarDatosJugador();
                    break;
                case 2:
                    insertarDatosClub();
                    break;
                case 3:
                    modificarDatos();
                    break;
                case 4:
                    asociarFutbolistaClub();
                    break;
                case 5:
                    listarFutbolistasClub();
                    break;
                case 6:
                    listarClubesFutbolista();
                    break;
                case 7:
                    listarClubes();
                    break;
                case 8:
                    listarJugadores();
                    break;
                case 0:
                    System.out.println("¡Hasta otra!");
                    break;
                default:
                    System.out.println("La opción es inválida. Introduce un número válido.");
                    break;
            }
        } while (opcion != 0);
    }

    /**
     * Método para mostrar el menú.
     */
    private static void mostrarMenu() {
        System.out.println("---- MENÚ ----");
        System.out.println("A continuación, se mostrarán las distintas acciones que puede realizar.");
        System.out.println("1. Introducir datos de futbolistas.");
        System.out.println("2. Introducir datos de clubes de fútbol.");
        System.out.println("3. Modificar datos de futbolistas y clubes.");
        System.out.println("4. Asociar futbolistas a clubes.");
        System.out.println("5. Obtener la lista de los futbolistas asociados a un club.");
        System.out.println("6. Obtener la lista de los clubes en los que ha militado un futbolista.");
        System.out.println("7. Listar todos los clubes.");
        System.out.println("8. Listar todos los jugadores.");
        System.out.println("0. Salir de la aplicación.");
        System.out.println("Indique aquí la opción que desea elegir: ");
    }

    /**
     * Método para introducir datos de un jugador.
     */
    private static void insertarDatosJugador() {
        System.out.println("Ha seleccionado la opción 1. Introduzca a continuación los datos del futbolista: ");
        System.out.print("NIF: ");
        String nif = escaner.nextLine();
        System.out.println("Nombre: ");
        String nombre = escaner.nextLine();
        System.out.print("Primer apellido: ");
        String apellido1 = escaner.nextLine();
        System.out.print("Segundo apellido: ");
        String apellido2 = escaner.nextLine();
        System.out.print("Nacionalidad: ");
        String nacionalidad = escaner.nextLine();
        System.out.print("Fecha de nacimiento: ");
        String fechaNacimientoStr = escaner.nextLine();

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date utilDate = sdf.parse(fechaNacimientoStr);
            java.sql.Date fecha = new java.sql.Date(utilDate.getTime());

            Jugador jugador = new Jugador(nif, nombre, apellido1, apellido2, nacionalidad, fecha);
            jugadorDAO.createJugador(jugador);

        } catch (ParseException e) {
            System.out.println("El formato de la fecha es incorrecto. Inténtelo de nuevo: " + e.getMessage());
            return; //Asegura el ingreso de una fecha válida.
        }

    }

    /**
     * Método para insertar datos de un club.
     *
     * @throws SQLException
     */
    private static void insertarDatosClub() throws SQLException {
        System.out.println("Ha seleccionado la opción 2. Introduzca a continuación los datos del club: ");
        System.out.println("Nombre del club: ");
        String nombre = escaner.nextLine();
        System.out.println("Año de creación: ");
        int annoCreacion = escaner.nextInt();
        escaner.nextLine(); //Limpia el búfer de entrada.
        System.out.println("Estadio: ");
        String estadio = escaner.nextLine();

        Club club = new Club(nombre, annoCreacion, estadio);
        clubDAO.createClub(club);
        System.out.println("El club ha sido añadido correctamente.");
    }

    /**
     * Método para modificar datos.
     *
     * @throws SQLException
     */
    private static void modificarDatos() throws SQLException {
        System.out.println("Ha seleccionado la opción 3.");
        System.out.println("¿Qué desea modificar?");
        System.out.println("1. Modificar un jugador.");
        System.out.println("2. Modificar un club.");
        System.out.println("Indique aquí la opción que desea: ");
        int opcion = escaner.nextInt();
        escaner.nextLine();

        switch (opcion) {
            case 1:
                modificarDatosJugador();
                break;
            case 2:
                modificarDatosClub();
                break;
            default:
                System.out.println("Opción inválida. Introduzca un número válido.");
                break;
        }
    }

    /**
     * Método para modificar los datos de un jugador.
     *
     * @throws SQLException
     */
    private static void modificarDatosJugador() throws SQLException {
        System.out.println("Ha elegido la opción 1. Inserte el NIF del jugador que desea modificar: ");
        String nif = escaner.nextLine();
        Jugador jugador = jugadorDAO.buscarNif(nif);

        if (jugador != null) {
            System.out.println("Modifique los datos del jugador.");
            System.out.println("Nombre: ");
            String nuevoNombre = escaner.nextLine();
            System.out.println("Primer apellido: ");
            String nuevoApellido1 = escaner.nextLine();
            System.out.println("Segundo apellido: ");
            String nuevoApellido2 = escaner.nextLine();
            System.out.println("Nacionalidad: ");
            String nuevaNacionalidad = escaner.nextLine();
            System.out.println("Fecha de Nacimiento (AAAA-MM-DD): ");
            String nuevaNacimientoStr = escaner.nextLine();

            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                java.util.Date utilDate = sdf.parse(nuevaNacimientoStr);
                Calendar calendario = Calendar.getInstance();
                calendario.setTime(utilDate);
                int year = calendario.get(Calendar.YEAR);
                int month = calendario.get(Calendar.MONTH);
                int day = calendario.get(Calendar.DAY_OF_MONTH);
                java.sql.Date nuevaFecha = new java.sql.Date(year - 1900, month, day);

                jugador.setNombreJugador(nuevoNombre);
                jugador.setApellido1(nuevoApellido1);
                jugador.setApellido2(nuevoApellido2);
                jugador.setNacionalidad(nuevaNacionalidad);
                jugador.setNacimiento(nuevaFecha);

                jugadorDAO.updateJugador(jugador);
                System.out.println("Los datos del jugador se han actualizado correctamente.");
            } catch (ParseException e) {
                System.out.println("El formato de la fecha es incorrecto. Inténtelo de nuevo: " + e.getMessage());
                return; //Asegura el ingreso de una fecha válida.
            }

        } else {
            System.out.println("No se encontró ningún jugador con este NIF.");
        }
    }

    /**
     * Método para modificar los datos de un club.
     *
     * @throws SQLException
     */
    private static void modificarDatosClub() throws SQLException {
        System.out.println("Ha elegido la opción 2. Introduzca el ID del club que quiere modificar: ");
        int idClub = escaner.nextInt();
        escaner.nextLine();

        Club club = clubDAO.buscarIdClub(idClub);

        if (club != null) {
            System.out.println("Inserte los datos que quiere modificar.");
            System.out.println("Nuevo nombre del club: ");
            String nuevoNombre = escaner.nextLine();
            System.out.println("Año de creación: ");
            int nuevoAnnoCreacion = escaner.nextInt();
            escaner.nextLine();
            System.out.println("Estadio: ");
            String nuevoEstadio = escaner.nextLine();

            club.setNombreClub(nuevoNombre);
            club.setAnnoCreacion(nuevoAnnoCreacion);
            club.setEstadio(nuevoEstadio);

            clubDAO.updateClub(club);
        } else {
            System.out.println("No se encontró ningún club con este ID.");
        }
    }

    /**
     * Método para asociar un jugador a un club.
     * 
     * @throws SQLException 
     */
    public static void asociarFutbolistaClub() throws SQLException {
        Scanner escaner = new Scanner(System.in);
        System.out.println("Ha seleccionado la opción 4.");
        System.out.println("Ingrese el NIF del jugador: ");
        String nif = escaner.nextLine();
        System.out.println("Ingrese el nombre del club: ");
        String nombreClub = escaner.nextLine();
        System.out.println("Ingrese la division");
        int division = escaner.nextInt();
        escaner.nextLine();
        System.out.println("Ingrese la temporada: ");
        String temporada = escaner.nextLine();

        try {
            String obtenerIdClub = "SELECT C_ID_Club FROM CLUB WHERE C_Nombre_Club = '?'";
            String obtenerIdMilitancia = "SELECT C_ID_Militancia FROM HISTORIAL_CLUB WHERE C_ID_Club = '?' AND C_Temporada = '?'";
            String asociarJugador = "INSERT INTO HISTORIAL_JUGADOR (C_ID_Militancia, C_NIF) VALUES (?, ?)";

            ConexionBD conexion = new ConexionBD();
            conexion.openConnect();

            try (
                     PreparedStatement stmtObtenerIdClub = conexion.getCx().prepareStatement(obtenerIdClub);  PreparedStatement stmtObtenerIdMilitancia = conexion.getCx().prepareCall(obtenerIdMilitancia);  PreparedStatement stmtAsociarJugador = conexion.getCx().prepareCall(asociarJugador)) {

                //Obtener ID del club.
                stmtObtenerIdClub.setString(1, nombreClub);
                ResultSet resIdClub = stmtObtenerIdClub.executeQuery();

                if (resIdClub.next()) {
                    int idClub = resIdClub.getInt("C_ID_Club");

                    //Obtener ID_Militancia del club.
                    stmtObtenerIdMilitancia.setInt(1, idClub);
                    stmtObtenerIdMilitancia.setString(2, temporada);

                    ResultSet resIdMilitancia = stmtObtenerIdMilitancia.executeQuery();
                    if (resIdMilitancia.next()) {
                        int idMilitancia = resIdMilitancia.getInt("C_ID_Militancia");

                        //Asociar el jugador al club en la tabla Historial_Jugador.
                        stmtAsociarJugador.setInt(1, idMilitancia);
                        stmtAsociarJugador.setString(2, nif);
                        stmtAsociarJugador.executeUpdate();
                        System.out.println("El jugador ha sido asociado al club correctamente.");
                    } else {
                        System.out.println("No se encontró la militancia del club para dicha temporada.");
                    }

                } else {
                    System.out.println("No se encontró el club especificado.");
                }

            } catch (SQLException e) {
                System.err.println("Error al asociar el jugador al club: " + e.getMessage());
            }
        } catch (InputMismatchException e) {
            System.err.println("Error: se ingresó un valor incorrecto.");
        }

    }

    /**
     * Método para asociar jugadores a un club.
     *
     * @throws SQLException
     */
    //    private static void asociarFutbolistaClub() throws SQLException {
    //        System.out.println("Ha seleccionado la opción 4.");
    //
    //        ConexionBD conexion = new ConexionBD();
    //        conexion.openConnect();
    //        System.out.println("Introduzca el NIF del jugador que quiere asociar: ");
    //        String nif = escaner.nextLine();
    //        System.out.println("Ahora indique el nombre del club al que quiere asociarlo.");
    //        String nombreClub = escaner.nextLine();
    //
    //        try {
    //            Jugador jugador = jugadorDAO.buscarNif(nif);
    //            Club club = clubDAO.buscarNombre(nombreClub);
    //
    //            if (jugador != null && club != null) {
    //                jugadorDAO.asociarJugadorClub(jugador, club);
    //                System.out.println("El jugador ha sido asociado correctamente al club en la base de datos.");
    //            } else {
    //                System.out.println("No se encontró el jugador o el club en la base de datos.");
    //            }
    //        } catch (SQLException e) {
    //            System.err.println("Error al asociar el futbolista al club: " + e.getMessage());
    //            throw e;
    //        }
    //        conexion.closeConnect();
    //    }
    /**
     * Método para listar los jugadores de un club.
     *
     * @throws SQLException
     */
    private static void listarFutbolistasClub() throws SQLException {
        System.out.println("Ha seleccionado la opción 5. Introduzca el nombre del club: ");
        String nombreClub = escaner.nextLine();

        try {
            Club club = clubDAO.buscarNombre(nombreClub);

            if (club != null) {
                System.out.println("Jugadores asociados al club " + nombreClub + ": ");

                for (Jugador jugador : club.getFutbolistas()) {
                    System.out.println(jugador);
                }
            } else {
                System.out.println("No se encontró el club en la base de datos.");
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener la lista de jugadores del club: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Método para listar los clubes en los que ha militado un jugador.
     *
     * @throws SQLException
     */
    private static void listarClubesFutbolista() throws SQLException {
        System.out.println("Ha seleccionado la opción 6. Introduzca el NIF del jugador: ");
        String nif = escaner.nextLine();

        Jugador jugador = jugadorDAO.buscarNif(nif);
        if (jugador != null) {
            System.out.println("Clubes en los que ha militado el futbolista con NIF " + nif + ": ");

            for (Club club : jugador.getClubes()) {
                System.out.println(club);
            }
        } else {
            System.out.println("No se encontró el jugador en la base de datos.");
        }
    }

    /**
     * Método para listar todos los clubes.
     *
     * @throws SQLException
     */
    private static void listarClubes() throws SQLException {
        System.out.println("Has seleccionado la opción 7.");

        ConexionBD conexion = new ConexionBD();
        conexion.openConnect();
        System.out.println("A continuación tiene el listado de clubes: ");
        for (Object club : clubDAO.readClub()) {
            System.out.println(club);
        }
        conexion.closeConnect();
    }

    /**
     * Método para listar todos los jugadores.
     *
     * @throws SQLException
     */
    private static void listarJugadores() throws SQLException {
        System.out.println("Ha seleccionado la opción 8.");

        ConexionBD conexion = new ConexionBD();
        conexion.openConnect();
        System.out.println("A continuación aparecerá la lista de los jugadores:  ");
        for (Jugador jugador : jugadorDAO.readJugador()) {
            System.out.println(jugador);
        }
        conexion.closeConnect();
    }

}
